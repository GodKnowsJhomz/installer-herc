#!/bin/sh
cd /home/hercules/Desktop/rAthena
./login-server
