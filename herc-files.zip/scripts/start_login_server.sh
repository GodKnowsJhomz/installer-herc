#!/bin/sh
cd /home/hercules/Desktop/hercules
./login-server
