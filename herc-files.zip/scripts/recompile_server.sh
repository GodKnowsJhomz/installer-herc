#!/bin/sh
zenity --question --title="Ragnarok Installer" --text="Are you sure you want to recompile your server? \n\n THIS CAN TAKE UPTO 5 MINUTES TO COMPLETE."
if [ $? = 0 ]; then
	cd /home/hercules/Desktop/hercules
 	xterm -title "Compile Hercules" -bg black -fg white -e ./configure
	xterm -title "Compile Hercules" -bg black -fg white -e make clean
	xterm -title "Compile Hercules" -bg black -fg white -e make sql plugins
	zenity --info --title="Ragnarok Installer" --text="Your Hercules server has been recompiled."
else
	exit
fi
