#!/bin/sh
#echo "Please enter a new password (you will not see anything appear on the screen), you will need to then verify by typing your new password again."
passwd