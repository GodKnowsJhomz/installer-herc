#!/bin/sh
cd /home/hercules/Desktop/rAthena
./map-server
