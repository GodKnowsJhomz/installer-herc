#!/bin/sh
cd /home/hercules/Desktop/hercules
./map-server
