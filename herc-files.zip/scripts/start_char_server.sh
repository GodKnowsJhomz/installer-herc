#!/bin/sh
cd /home/hercules/Desktop/rAthena
./char-server
