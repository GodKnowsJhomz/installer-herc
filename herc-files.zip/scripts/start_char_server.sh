#!/bin/sh
cd /home/hercules/Desktop/hercules
./char-server
