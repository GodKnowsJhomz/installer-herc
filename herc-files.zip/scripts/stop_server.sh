#!/bin/sh
zenity --question --title="Ragnarok Installer" --text="Are you sure you would like to turn off your Hercules server?"
if [ $? = 0 ]; then
	killall -9 login-server
	killall -9 char-server
	killall -9 map-server
	zenity --info --title="Ragnarok Installer" --text="Your Hercules server has been stopped." 
else
	exit
fi
