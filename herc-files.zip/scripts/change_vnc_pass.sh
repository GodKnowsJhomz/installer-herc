#!/bin/sh
CERV_DIR=/usr/share/ragnainstaller
xterm -title "Change VNC Password" -bg black -fg white -hold -e sh $CERV_DIR/scripts/change_vnc_pass_script.sh &